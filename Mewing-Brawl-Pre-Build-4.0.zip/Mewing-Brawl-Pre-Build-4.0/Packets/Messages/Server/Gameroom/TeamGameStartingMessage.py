from Utils.Writer import Writer


class TeamGameStartingMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24130
        self.player = player

    def encode(self):
        print("12")
        brawler_level = self.player.Brawler_level[str(self.player.brawler_id)]
        self.writeVint(0)
        self.writeVint(0)
    
        self.writeVint(23)
        self.writeVint(0)