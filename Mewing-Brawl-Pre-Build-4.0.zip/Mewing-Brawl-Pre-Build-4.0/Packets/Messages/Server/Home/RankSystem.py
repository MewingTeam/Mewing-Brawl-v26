from Database.DatabaseManager import DataBase
from Utils.Writer import Writer
from Utils.Reader import BSMessageReader


class RankSystem(BSMessageReader):
	
	def __init__(self,player,client):
		super().__init__(client)
		self.player = player
		
		def encode(self):
			print("check")
			if self.player.rank == 1:
				self.player.brawl_boxes = self.player.brawl_boxes + 100
				DataBase.replaceValue(self,'brawlBoxes',self.player.brawl_boxes)		
				if self.player.rank < 1:
					print("8")
			