from Database.DatabaseManager import DataBase
from Packets.Messages.Server.Home.OwnHomeDataMessage import OwnHomeDataMessage
import time
from Utils.Reader import BSMessageReader


class GoHomeFromOfflinePractiseMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client

    def decode(self):
        pass

    def process(self):
       self.player.trophies = self.player.trophies - 10
       DataBase.replaceValue(self,'trophies',self.player.trophies)
       self.player.brawlers_trophies[str(self.player.brawler_id)] = self.player.brawlers_trophies[str(self.player.brawler_id)] - 10
       DataBase.replaceValue(self,'brawler_trophies',self.player.brawlers_trophies[str(self.player.brawler_id)])
       OwnHomeDataMessage(self.client, self.player).send()
        	