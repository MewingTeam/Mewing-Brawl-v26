from Logic.Shop import Shop
from Shop import offers
