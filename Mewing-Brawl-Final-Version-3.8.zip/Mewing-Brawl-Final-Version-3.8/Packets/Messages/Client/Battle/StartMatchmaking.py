
from Packets.Messages.Server.Gameroom.TeamGameStartingMessage import TeamGameStartingMessage
from Utils.Reader import BSMessageReader


class StartMatchmaking(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)
        self.player = player
        self.client = client


    def decode(self):
        pass

    def process(self,initial_bytes):
      TeamGameStartingMessage(self.player,self.client).send()