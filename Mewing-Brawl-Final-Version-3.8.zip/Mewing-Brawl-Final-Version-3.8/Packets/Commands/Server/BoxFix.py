from Database.DatabaseManager import DataBase

class BoxesFix():
     
     def __init__(self, client, player):
        super().__init__(client)
        self.client = client
        self.player = player
        self = self
        
        def pr(self):
        	bn = self.player.brawl_boxes
        	print("sjsjhshsh")
        	DataBase.replaceValue(self,'brawlBoxes',bn - 100)